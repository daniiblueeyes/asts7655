To do
=====

For interested developers:

* Accessibility: *android:labelFor="..."*
* [Open issues](https://github.com/M66B/XPrivacy/issues?state=open)
* Revoke BLUETOOTH, NFC, USE_SIP

Android source code
-------------------

git clone https://android.googlesource.com/platform/libcore -b master
git clone https://android.googlesource.com/platform/frameworks/base -b l-preview
